from django.urls import path
from django.contrib.auth import views as auth_view
from . import views
urlpatterns = [
    path('',views.home,name="home"),
    path("register/",views.register_request,name="register"),
    path('login/',views.login_request,name="login"),
    path('logout/',auth_view.LogoutView.as_view(template_name='logout.html'),name='logout'),
    path('profile',views.profile,name='profile')
]