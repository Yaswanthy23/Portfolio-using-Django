from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.contrib.auth import login,authenticate
from django.contrib import messages
from .forms import NewUserForm
from django.contrib.auth.forms import AuthenticationForm
# Create your views here.

def home(request):
    return render(request,'base.html')

def register_request(request):
    form = NewUserForm()
    if request.method == 'POST':
        form = NewUserForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request,f'Hello {username}, Your Account is Created')
            return redirect('home')
        else:
            form=NewUserForm()
    return render(request,'register.html',{'register_form':form})

def login_request(request):
    form = AuthenticationForm()
    if request.method=="POST":
        form=AuthenticationForm(request,request.POST)
        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(username=username,password=password)
            if user is not None:
                login(request,user)
                messages.info(request,"You have been Logged in")
                return redirect('home')
            else:
                messages.error(request,"Invalid Details")
    return render(request,'login.html',{'login_form':form})

@login_required()
def profile(request):
    return  render(request,'profile.html')
